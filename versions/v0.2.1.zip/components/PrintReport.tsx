
import React from 'react';
import { Project, WorkItem } from '../types';
import { financial } from '../utils/math';
import { HardHat } from 'lucide-react';

interface PrintReportProps {
  project: Project;
  data: (WorkItem & { depth: number })[];
  stats: {
    contract: number;
    current: number;
    accumulated: number;
    balance: number;
    progress: number;
  };
}

export const PrintReport: React.FC<PrintReportProps> = ({ project, data, stats }) => {
  // Cálculo de acumulado anterior geral para o cabeçalho
  const previousTotalHeader = financial.sum(project.history?.map(h => h.totals.period) || []);

  return (
    <div className="print-only font-sans p-2 text-black bg-white">
      {/* CABEÇALHO DO RELATÓRIO */}
      <div className="flex justify-between items-center border-b-2 border-black pb-4 mb-4">
        <div className="flex flex-col">
          <h1 className="text-2xl font-black uppercase tracking-tighter">PLANILHA DE MEDIÇÃO</h1>
          <div className="mt-2 text-[10px] font-bold">
            <p><span className="text-slate-500">Local:</span> {project.name.toUpperCase()}</p>
            <p><span className="text-slate-500">Contratada:</span> {project.companyName.toUpperCase()}</p>
          </div>
        </div>
        <div className="text-right flex flex-col items-end">
          <div className="font-black text-xs uppercase mb-1">
            Medição Nº: <span className="text-lg">{project.measurementNumber}</span>
          </div>
          <p className="text-[10px] font-bold">Data: {project.referenceDate}</p>
        </div>
      </div>

      {/* BOXES DE RESUMO SUPERIOR */}
      <div className="grid grid-cols-5 gap-2 mb-6">
        <SummaryBox label="CONTRATO TOTAL" value={stats.contract} />
        <SummaryBox label="ACUM. ANTERIOR" value={previousTotalHeader} />
        <SummaryBox label="MEDIÇÃO DO PERÍODO" value={stats.current} highlight="blue" />
        <SummaryBox label="ACUMULADO TOTAL" value={stats.accumulated} highlight="emerald" />
        <SummaryBox label="SALDO A REALIZAR" value={stats.balance} highlight="rose" />
      </div>

      {/* TABELA DE MEDIÇÃO COMPLETA */}
      <table className="print-table w-full border-collapse border border-black">
        <thead className="bg-slate-800 text-white uppercase text-[7px] font-black">
          <tr>
            <th rowSpan={2} className="border border-black p-1 w-8">ITEM</th>
            <th rowSpan={2} className="border border-black p-1 w-12">CÓD</th>
            <th rowSpan={2} className="border border-black p-1 w-12">FONTE</th>
            <th rowSpan={2} className="border border-black p-1">DESCRIÇÃO</th>
            <th rowSpan={2} className="border border-black p-1 w-10">UND</th>
            <th rowSpan={2} className="border border-black p-1 w-16">UNIT (S/BDI)</th>
            <th rowSpan={2} className="border border-black p-1 w-16">UNIT (C/BDI)</th>
            <th rowSpan={2} className="border border-black p-1 w-16">QTD. CONTRATADO</th>
            <th rowSpan={2} className="border border-black p-1 w-24">TOTAL (R$) CONTRATADO</th>
            <th colSpan={2} className="border border-black p-1 bg-slate-700">ACUM. ANTERIOR</th>
            <th colSpan={2} className="border border-black p-1 bg-blue-900">MEDIÇÃO DO PERÍODO</th>
            <th colSpan={2} className="border border-black p-1 bg-emerald-900">ACUM. TOTAL</th>
            <th colSpan={2} className="border border-black p-1 bg-rose-900">SALDO A REALIZAR</th>
            <th rowSpan={2} className="border border-black p-1 w-12">% EXECUTADO</th>
          </tr>
          <tr className="bg-slate-700">
            <th className="border border-black p-0.5 w-12 text-[6px]">QUANT.</th>
            <th className="border border-black p-0.5 w-16 text-[6px]">TOTAL (R$)</th>
            <th className="border border-black p-0.5 w-12 text-[6px] bg-blue-800">QUANT.</th>
            <th className="border border-black p-0.5 w-16 text-[6px] bg-blue-800">TOTAL (R$)</th>
            <th className="border border-black p-0.5 w-12 text-[6px] bg-emerald-800">QUANT.</th>
            <th className="border border-black p-0.5 w-16 text-[6px] bg-emerald-800">TOTAL (R$)</th>
            <th className="border border-black p-0.5 w-12 text-[6px] bg-rose-800">QUANT.</th>
            <th className="border border-black p-0.5 w-16 text-[6px] bg-rose-800">TOTAL (R$)</th>
          </tr>
        </thead>
        <tbody className="text-[7px]">
          {data.map(item => (
            <tr key={item.id} className={`${item.type === 'category' ? 'bg-slate-100 font-bold' : ''} break-inside-avoid`}>
              <td className="border border-black text-center font-mono">{item.wbs}</td>
              <td className="border border-black text-center">{item.cod || '—'}</td>
              <td className="border border-black text-center uppercase">{item.fonte || '—'}</td>
              <td className="border border-black text-left font-medium px-1 uppercase" style={{ paddingLeft: `${item.depth * 8 + 4}px` }}>
                {item.name}
              </td>
              <td className="border border-black text-center uppercase">{item.unit || '—'}</td>
              <td className="border border-black text-right">{item.type === 'item' ? financial.formatBRL(item.unitPriceNoBdi).replace('R$', '') : '—'}</td>
              <td className="border border-black text-right">{item.type === 'item' ? financial.formatBRL(item.unitPrice).replace('R$', '') : '—'}</td>
              <td className="border border-black text-center">{item.type === 'item' ? item.contractQuantity : '—'}</td>
              <td className="border border-black text-right">{financial.formatBRL(item.contractTotal).replace('R$', '')}</td>
              
              {/* Acumulado Anterior */}
              <td className="border border-black text-center text-slate-500">{item.type === 'item' ? (item.previousQuantity || '—') : '—'}</td>
              <td className="border border-black text-right text-slate-500">{financial.formatBRL(item.previousTotal).replace('R$', '')}</td>
              
              {/* Medição do Período */}
              <td className="border border-black text-center font-bold">{item.type === 'item' ? (item.currentQuantity || '—') : '—'}</td>
              <td className="border border-black text-right font-bold">{financial.formatBRL(item.currentTotal).replace('R$', '')}</td>
              
              {/* Acumulado Total */}
              <td className="border border-black text-center font-bold bg-slate-50">{item.type === 'item' ? (item.accumulatedQuantity || '—') : '—'}</td>
              <td className="border border-black text-right font-bold bg-slate-50">{financial.formatBRL(item.accumulatedTotal).replace('R$', '')}</td>
              
              {/* Saldo a Realizar */}
              <td className="border border-black text-center text-slate-400">{item.type === 'item' ? (item.balanceQuantity || '—') : '—'}</td>
              <td className="border border-black text-right text-slate-400">{financial.formatBRL(item.balanceTotal).replace('R$', '')}</td>
              
              <td className="border border-black text-center font-black">
                {item.type === 'category' ? `${item.accumulatedPercentage.toFixed(2)}%` : `${item.accumulatedPercentage.toFixed(2)}%`}
              </td>
            </tr>
          ))}
          {/* TOTAL GERAL */}
          <tr className="bg-black text-white font-black uppercase text-[8px]">
            <td colSpan={8} className="border border-black p-2 text-right tracking-widest">TOTAL GERAL DO EMPREENDIMENTO</td>
            <td className="border border-black p-2 text-right">{financial.formatBRL(stats.contract)}</td>
            <td className="border border-black p-2 text-center">—</td>
            <td className="border border-black p-2 text-right">{financial.formatBRL(previousTotalHeader)}</td>
            <td className="border border-black p-2 text-center">—</td>
            <td className="border border-black p-2 text-right text-blue-400">{financial.formatBRL(stats.current)}</td>
            <td className="border border-black p-2 text-center">—</td>
            <td className="border border-black p-2 text-right text-emerald-400">{financial.formatBRL(stats.accumulated)}</td>
            <td className="border border-black p-2 text-center">—</td>
            <td className="border border-black p-2 text-right text-rose-400">{financial.formatBRL(stats.balance)}</td>
            <td className="border border-black p-2 text-center">{stats.progress.toFixed(2)}%</td>
          </tr>
        </tbody>
      </table>

      {/* RODAPÉ DE ASSINATURAS */}
      <div className="mt-12 grid grid-cols-3 gap-10 break-inside-avoid">
        <SignatureLine label="Responsável Técnico" subLabel={project.companyName} />
        <SignatureLine label="Fiscalização" subLabel="Órgão / Cliente" />
        <SignatureLine label="Gestor do Contrato" subLabel="Aprovação Final" />
      </div>
    </div>
  );
};

const SummaryBox = ({ label, value, highlight }: { label: string, value: number, highlight?: 'blue' | 'emerald' | 'rose' }) => {
  const colors = {
    blue: 'text-blue-700 border-blue-200 bg-blue-50',
    emerald: 'text-emerald-700 border-emerald-200 bg-emerald-50',
    rose: 'text-rose-700 border-rose-200 bg-rose-50',
    default: 'text-slate-900 border-slate-200 bg-slate-50'
  };
  
  return (
    <div className={`border p-3 rounded-lg flex flex-col items-start ${highlight ? colors[highlight] : colors.default}`}>
      <span className="text-[7px] font-black uppercase tracking-widest opacity-60 mb-1">{label}</span>
      <span className="text-xs font-black leading-none">{financial.formatBRL(value)}</span>
    </div>
  );
};

const SignatureLine = ({ label, subLabel }: { label: string, subLabel: string }) => (
  <div className="flex flex-col items-center text-center">
    <div className="w-full border-t border-black mb-1"></div>
    <span className="text-[8px] font-black uppercase">{label}</span>
    <span className="text-[7px] text-slate-500 uppercase">{subLabel}</span>
  </div>
);
