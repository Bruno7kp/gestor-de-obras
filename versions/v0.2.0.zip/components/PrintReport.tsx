
import React from 'react';
import { Project, WorkItem } from '../types';
import { financial } from '../utils/math';
import { HardHat } from 'lucide-react';

interface PrintReportProps {
  project: Project;
  data: (WorkItem & { depth: number })[];
  stats: {
    contract: number;
    current: number;
    accumulated: number;
    balance: number;
    progress: number;
  };
}

export const PrintReport: React.FC<PrintReportProps> = ({ project, data, stats }) => {
  return (
    <div className="print-only font-sans p-2">
      {/* CABEÇALHO DO RELATÓRIO */}
      <div className="print-header flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-black flex items-center justify-center text-white rounded">
            <HardHat size={32} />
          </div>
          <div>
            <h1 className="text-xl font-black uppercase leading-tight">{project.companyName}</h1>
            <p className="text-xs font-bold text-slate-600">SISTEMA INTEGRADO DE MEDIÇÃO DE OBRAS</p>
          </div>
        </div>
        <div className="text-right">
          <h2 className="text-lg font-black uppercase">Boletim de Medição</h2>
          <p className="text-sm font-bold">MEDICÃO Nº: {project.measurementNumber}</p>
          <p className="text-[10px] font-medium">EMITIDO EM: {new Date().toLocaleString('pt-BR')}</p>
        </div>
      </div>

      {/* DADOS DO PROJETO */}
      <div className="grid grid-cols-3 gap-4 mb-6 border p-4 bg-slate-50 rounded">
        <div>
          <label className="text-[8px] font-black uppercase text-slate-500 block">Empreendimento</label>
          <span className="text-xs font-bold">{project.name}</span>
        </div>
        <div>
          <label className="text-[8px] font-black uppercase text-slate-500 block">Data de Referência</label>
          <span className="text-xs font-bold">{project.referenceDate}</span>
        </div>
        <div>
          <label className="text-[8px] font-black uppercase text-slate-500 block">Status Físico</label>
          <span className="text-xs font-bold">{stats.progress.toFixed(2)}% Concluído</span>
        </div>
      </div>

      {/* TABELA DE MEDIÇÃO */}
      <table className="print-table mb-8">
        <thead>
          <tr>
            <th className="w-12">WBS</th>
            <th className="text-left">Descrição dos Serviços</th>
            <th className="w-10">Und</th>
            <th className="w-20">Qtd Contrato</th>
            <th className="w-24">Preço Unit.</th>
            <th className="w-28">Total Contrato</th>
            <th className="w-16">Qtd Medida</th>
            <th className="w-28">Total Medição</th>
            <th className="w-28">Total Acumulado</th>
          </tr>
        </thead>
        <tbody>
          {data.map(item => (
            <tr key={item.id} className={item.type === 'category' ? 'font-bold bg-slate-100' : ''}>
              <td className="text-center font-mono text-[9px]">{item.wbs}</td>
              <td className="text-left" style={{ paddingLeft: `${item.depth * 10 + 4}px` }}>
                {item.type === 'category' ? item.name.toUpperCase() : item.name}
              </td>
              <td className="text-center uppercase">{item.unit || '-'}</td>
              <td className="text-center">{item.type === 'item' ? item.contractQuantity : '-'}</td>
              <td className="text-right">{item.type === 'item' ? financial.formatBRL(item.unitPrice) : '-'}</td>
              <td className="text-right">{financial.formatBRL(item.contractTotal)}</td>
              <td className="text-center">{item.type === 'item' ? item.currentQuantity : '-'}</td>
              <td className="text-right font-bold">{financial.formatBRL(item.currentTotal)}</td>
              <td className="text-right">{financial.formatBRL(item.accumulatedTotal)}</td>
            </tr>
          ))}
          {/* RODAPÉ FINANCEIRO */}
          <tr className="bg-black text-white font-black uppercase">
            <td colSpan={5} className="text-right p-2">Totais Consolidados da Medição:</td>
            <td className="text-right">{financial.formatBRL(stats.contract)}</td>
            <td></td>
            <td className="text-right">{financial.formatBRL(stats.current)}</td>
            <td className="text-right">{financial.formatBRL(stats.accumulated)}</td>
          </tr>
        </tbody>
      </table>

      {/* QUADRO DE RESUMO */}
      <div className="signature-box grid grid-cols-4 gap-4 mb-12">
        <div className="border p-4 text-center">
          <p className="text-[10px] font-black uppercase text-slate-500 mb-2">Contratado</p>
          <p className="text-lg font-black">{financial.formatBRL(stats.contract)}</p>
        </div>
        <div className="border p-4 text-center">
          <p className="text-[10px] font-black uppercase text-slate-500 mb-2">Medido no Período</p>
          <p className="text-lg font-black">{financial.formatBRL(stats.current)}</p>
        </div>
        <div className="border p-4 text-center">
          <p className="text-[10px] font-black uppercase text-slate-500 mb-2">Acumulado</p>
          <p className="text-lg font-black">{financial.formatBRL(stats.accumulated)}</p>
        </div>
        <div className="border p-4 text-center">
          <p className="text-[10px] font-black uppercase text-slate-500 mb-2">Saldo à Executar</p>
          <p className="text-lg font-black">{financial.formatBRL(stats.balance)}</p>
        </div>
      </div>

      {/* ASSINATURAS */}
      <div className="signature-box grid grid-cols-3 gap-8 mt-20">
        <div className="text-center">
          <div className="border-t border-black mb-2"></div>
          <p className="text-[10px] font-black uppercase">Responsável Técnico</p>
          <p className="text-[8px] text-slate-500 uppercase">{project.companyName}</p>
        </div>
        <div className="text-center">
          <div className="border-t border-black mb-2"></div>
          <p className="text-[10px] font-black uppercase">Fiscalização de Obra</p>
          <p className="text-[8px] text-slate-500 uppercase">Assinatura e Carimbo</p>
        </div>
        <div className="text-center">
          <div className="border-t border-black mb-2"></div>
          <p className="text-[10px] font-black uppercase">Contratante / Gestão</p>
          <p className="text-[8px] text-slate-500 uppercase">Aprovado em ___/___/___</p>
        </div>
      </div>
    </div>
  );
};
